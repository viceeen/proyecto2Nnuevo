<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
class CuentaRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'nombre' => 'required|alpha|min:2|max:20',
            'apellido' => 'required|alpha|min:2|max:20',
            'user' => 'required|min:2|max:20',
            'password' => 'required|min:2|max:20|confirmed',
        ];
    }

    public function messages():array
    {
        return [
            'nombre.required' => 'Indique un Nombre',
            'nombre.alpha' => 'Nombre debe tener solo letras',
            'nombre.min' => 'Nombre debe tener mínimo 2 letras',
            'nombre.max' => 'Nombre debe tener máximo 30 letras',
            'apellido.required' => 'Indique el Apellido',
            'apellido.alpha' => 'Apellido debe tener solo letras',
            'apellido.min' => 'Apellido debe tener mínimo 2 letras',
            'apellido.max' => 'Apellido debe tener máximo 30 letras',
            'user.required' => 'Indique un Nombre de Usuario',
            'user.min' => 'Nombre debe tener mínimo 2 letras',
            'user.max' => 'Nombre debe tener máximo 30 letras',
            'password.required' => 'Indique una Contraseña',
            'password.min' => 'Nombre debe tener mínimo 2 letras',
            'password.max' => 'Nombre debe tener máximo 30 letras',
            'password.confirmed' => 'Las Contraseñas no coinciden',
        ]; 
    } 
}
