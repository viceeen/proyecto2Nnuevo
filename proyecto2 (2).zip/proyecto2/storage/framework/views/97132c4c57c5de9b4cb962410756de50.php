
<?php $__env->startSection('contenido-principal'); ?>

<div class="container">
  <div class="row">
    <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-4">
        <div class="card mb-3 mt-3" style="width: 350px; height: 350px;">
          <img src="<?php echo e(asset('storage/' . $imagen->archivo)); ?>" class="card-img-top" alt="">
          <div class="card-body">
            <h5 class="card-title"><?php echo e($imagen->titulo); ?></h5>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vicen\OneDrive\Escritorio\proyecto2\resources\views/inicio/index.blade.php ENDPATH**/ ?>