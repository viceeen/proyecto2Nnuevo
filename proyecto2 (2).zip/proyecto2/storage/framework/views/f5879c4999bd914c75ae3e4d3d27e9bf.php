
<?php $__env->startSection('contenido-principal'); ?>
<form method="POST" action="<?php echo e(route('cuenta.autenticar')); ?>">
  <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label for="user" class="form-label">User</label>
    <input type="text" class="form-control" id="user" name="user" >
  </div>
  <div class="mb-3">
    <label for="password" class="form-label">Password</label>
    <input type="password" class="form-control" id="password" name="password">
  </div>
  <button type="submit" class="btn btn-primary">Iniciar Sesion</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vicen\OneDrive\Escritorio\proyecto2\resources\views/home/login.blade.php ENDPATH**/ ?>