
<?php $__env->startSection('contenido-principal'); ?>

<div class="container-fluid min-vh-100 d-flex flex-column justify-content-lg-center">
    <div class="row">
        <div class="card">
            <div class="card-body">
                <form>
                  <div class="col">
                      <div class="mb-3">
                        <label for="user" class="form-label">Usuario</label>
                        <input type="text" class="form-control" id="user" name="user">
                      </div>
                      <div class="mb-3">
                        <label for="contraseña" class="form-label">Contraseña</label>
                        <input type="password" class="form-control" name="contraseña" id="contraseña">
                      </div>
        
                      <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vicen\OneDrive\Escritorio\proyecto2\resources\views/home/index.blade.php ENDPATH**/ ?>